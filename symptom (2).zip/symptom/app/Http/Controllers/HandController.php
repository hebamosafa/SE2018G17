<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HandController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('hands.hands1');

    }
    public function index2()
    {
        //
        return view('hands.hands11');

    }
    public function index3()
    {
        //
        return view('hands.hands2');

    }
    public function index4()
    {
        //
        return view('hands.hands21');

    }
    public function index5()
    {
        //
        return view('hands.hands22');

    }
    public function index6()
    {
        //
        return view('hands.hands3');

    }
    public function index7()
    {
        //
        return view('hands.hands4');

    }
    public function index8()
    {
        //
        return view('hands.hands411');

    }
    public function index9()
    {
        //
        return view('hands.hands4111');

    }
    public function index10()
    {
        //
        return view('hands.hands41111');

    }
    public function index11()
    {
        //
        return view('hands.hands41112');

    }
    public function index12()
    {
        //
        return view('hands.hands4121');

    }
    public function index13()
    {
        //
        return view('hands.hands412');

    }
    public function index14()
    {
        //
        return view('hands.hands41');

    }
    public function index15()
    {
        //
        return view('hands.hands42');

    }
    public function index16()
    {
        //
        return view('hands.hands5');

    }
    public function index17()
    {
        //
        return view('hands.hands51');

    }
    public function index18()
    {
        //
        return view('hands.hands52');

    }
    public function index20()
    {
        //
        return view('hands.hands5211');

    }
    public function index21()
    {
        //
        return view('hands.hands5212');

    }
    public function index22()
    {
        //
        return view('hands.hands522');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
