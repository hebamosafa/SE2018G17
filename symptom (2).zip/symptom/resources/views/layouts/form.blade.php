





<form class="form-group" action="">
    
<div class="form-group">
    <label for="exampleInputEmail1">الإسم</label>
    <input type="text" size="2" class="form-control" id="" aria-describedby="" name="name" placeholder="أدخل إسمك" value="">


</div>
    
<div class="form-group">
    <label for="">العمر</label>
    <input type="number"  class="form-control" id="" aria-describedby="" name="age" placeholder="أدخل عمرك" value="">


</div>
    
<div class="form-group">
    <label for="">البريد الإلكتروني</label>
    <input type="email" class="form-control" id="" aria-describedby="" name="email" placeholder="أدخل بريدك الإلكتروني" value="">


</div>

<button  class="btn btn-outline-primary my-3 ">

أرسل
			</button><br>

</form>







