

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم القدم
    <br>انت تعاني من كسر في عظام قدمك، او خلع في مفاصل قدمك. توقف عما تفعله، واتصل بطبيبك الان، او اذهب الى قسم الطوارئ بالمستشفى القريب منك</p>
            
		<div id="demo" class="collapse">

		</div>
   
     
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection