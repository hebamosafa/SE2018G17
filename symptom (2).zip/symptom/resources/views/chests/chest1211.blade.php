

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
  ألم الصدر
    <br>
عندما يؤلمك صدرك، يمكن ان يكون من الصعب ان تتكلم عادة، اذا كنت تشعر بضيق في التنفس؛ لان الالم يمنع اخذ نفس عميق او اذا كانت هناك عملية اخرى تجعل تنفسك صعبا.

اتصل بطبيبك او قم بالترتيب للنقل الى المركز الطبي فورا. ربما انت تعاني من حالة طبية خطيرة، مثل: جلطات الدم في الرئة او انهيار الرئة الجزئي.

ارسل نتيجة التشخيص الى
	</p>
            
		
   
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection