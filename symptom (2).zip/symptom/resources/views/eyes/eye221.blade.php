

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    افرازات العين
    <br>
بالرغم من ان هناك حاجة للمزيد من التقييم للتاكد، الا انك ربما تعاني من سكتة دماغية ، او مرض عصبي اخر. اتصل بطبيبك الان.
	
	</p>
            
		
		    
	 
      <br>
      <br>
    
	
  </div>

      @include('layouts.form')

@endsection