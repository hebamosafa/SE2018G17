

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم الأذن عند الكبار
    <br>
	قد تعاني من عدوى في الاذن، تسمى التهاب الاذن الوسطى (otitis media). يصاحب هذا النوع من العدوى عادة، احتقان الانف، انخفاض السمع، الشعور بالمرض والحمى.

مع عدوى قناة الاذن التي تسمى اذن السباحين (swimmer's ear) ايضا، يسبب شد شحمة الاذن برفق الما، لكن يكون احتقان الانف واعراض البرد اقل احتمالا.

اتصل بطبيبك اليوم.

ارسل نتيجة التشخيص الى
	</p>
            
	
        
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection