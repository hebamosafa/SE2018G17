

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    جفاف الفم و العطش الشديد
    <br>
	قد تعاني من متلازمة شوغرن ، وهي حالة مناعية يعتقد فيها ان جهاز المناعة يقوم بمهاجمة انسجة معينة في الجسم، متضمنة الغدد التي تنتج اللعاب والدموع.

تحدث مع طبيبك عن هذه الاحتمالية؛ كي يتم تاكيد التشخيص او استبعاده. قد يوصي الطبيب بعلاجات لتحسين الاعراض او يقوم باحالتك الى اخصائي امراض المناعة الذاتية.
	</p>
            

        
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection