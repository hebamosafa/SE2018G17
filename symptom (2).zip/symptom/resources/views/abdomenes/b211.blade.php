@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الاسهال
  <br>
 الدم او الصديد في البراز الخاص بك، يثير القلق ويرجح وجود عدوى بكتيرية.

بعض انواع العدوى البكتيرية في القولون، يمكن ان تكون بسبب تلوث الطعام، لكن يمكن ان تنشا عدوى معينة بعد العلاج بالمضادات الحيوية.

يمكن للعلاج بالمضادات الحيوية ان يقتل بعض انواع البكتريا غير الضارة في القولون وينظفها، تاركا الفراغ لانواع البكتريا الاخرى ان تنمو وتتكاثر. عادة، نوع البكتريا الضار يمكن ان يسبب عدوى خطيرة في الامعاء، عندما يحدث هذا التغيير

</p>
            
		<div id="demo" class="collapse">

		</div>
   
  
		
	
  </div>
	</div>	
    
@endsection