@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الاسهال
  <br>
بعض انواع العدوى الاكثر خطورة، التي يمكن ان تؤدي الى اسهال، هي اقل احتمالا في حالتك؛ لانك لا تعانين من دم او صديد في برازك. بالرغم من ذلك، فان العدوى هي السبب الاكثر احتمالا لاسهالك الحاد. معرفة الاطعمة التي تناولتها حديثا، التي يمكن ان تكون ملوثة بالبكتريا او الطفيليات يمكن ان تكون مفيدة</h2>
				
</p>
            
		<div id="demo" class="collapse">

		</div>
   
      @include('layouts.form')
		
	
  </div>
	</div>	
    
@endsection