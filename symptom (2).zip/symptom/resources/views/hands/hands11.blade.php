
@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
   ألم المرفق
    <br>
.وفقا لاعراضك، ربما تعاني من عدوى، او كسر، او مسبب خطير اخر لالمك
				وبالرغم من ان معظم الناس الذين يعانون من هذه الاعراض لا يسلموا بفكرة وجود شيء خطير عندهم
				الا انه قد تكون فكرة جيدة بشكل عام، ان تطلب الاستشارة الطبية للتاكد
</p>
            
</div>
@include('layouts.form')

		</div>
   
    
		
    
@endsection