
@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
   الم اليد
    <br>
من المحتمل بانك تعاني من كسر في عظمة او خلع في مفصل. قد يتضح في نهاية المطاف .بانه مجرد التواء، الا ان الاشعة السينية على اليد، ستكون مطلوبة للتاكد من ذلك

</p>
            
		<div id="demo" class="collapse">

		</div>
   
   
    
	
  </div>

@include('layouts.form')
		
    
@endsection