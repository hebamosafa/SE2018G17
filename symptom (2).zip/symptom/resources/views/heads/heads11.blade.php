

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
      		
        تساقط الشعر

  <br>
  قد يشير تساقط الشعر المصاحب لتغيرات في شعر الراس الى وجود مجموعة من الحالات، تعرف باسم تساقط الشعر التندبي يسقط الشعر بسبب تلف بصيلات الشعر (الثقوب الدقيقة التي في الجلد، التي ينمو منها الشعر).

ربما يكون هذا بسبب تفاعل حساسية او تفاعل لمنتجات الشعر، مثل: صبغة الشعر او شامبو جديد.
 
</p>
            

		</div>
   
    @include('layouts.form')
	
  </div>
		
    
@endsection