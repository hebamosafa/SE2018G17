



@extends('layouts.app')

@section('content')



@foreach($posts as $post)




    





<div class="col-md-4 my-3 text-center table-bordered">
<div class=" " >
<a href="{{url('/post/show'.'/'.$post->id)}}">

<img class="img-fluid" style="height:300px;width:300px;"  src="{{asset('/assets/images/posts'.'/'.$post->image)}}">
</a>

</div>
</div>

<div class="col-md-8 my-3  text-right table-bordered">
<a href="{{url('/post/show'.'/'.$post->id)}}">
<h5 class="pt-3">{{$post->title}} </h5>
</a>
<hr class="py-3">
......{{  substr($post->postdescription, 0,50)}}
 <a style="color:black" href="{{url('/post/show'.'/'.$post->id)}}">


<p style="color:black">
إقرأ المزيد
</p>
<br>
<br>


</a>
<p style="color:gray">
قسم: {{$post->posttag}}
</p>

</div>
<hr>

@endforeach









@endsection