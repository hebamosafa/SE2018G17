$(document).ready(function(){
	// $(".sk-cube-grid").fadeOut(2000,function(){

	//   $("#loading").fadeOut(2000 , function(){

	//           $("body").css("overflow","auto")

	//   });

	// });



	/******hairloss*/

	$(".hairloss #_1 #begin").click(function() {
		$(".hairloss #_2").show();
		$(".hairloss #_1").hide();
	});

	$(".hairloss #_2 #yes_2").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_2").hide();
	});
	$(".hairloss #_3no #no_4").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_3no").hide();
	});
	$(".hairloss #_2 #no_2").click(function() {
		$(".hairloss #_22").show();
		$(".hairloss #_2").hide();
	});
	$(".hairloss #_22 #yes_2").click(function() {
		$(".hairloss #_33").show();
		$(".hairloss #_22").hide();
	});
	$(".hairloss #_22 #no_22").click(function() {
		$(".hairloss #_222").show();
		$(".hairloss #_22").hide();
	});

	$(".hairloss #_3 #yes_3").click(function() {
		$(".hairloss #_4").show();
		$(".hairloss #_3").hide();
	});

	$(".hairloss #_33 #yes_3").click(function() {
		$(".hairloss #_44").show();
		$(".hairloss #_33").hide();
	});

	$(".hairloss #_3 #no_3").click(function() {
		$(".hairloss #_3no").show();
		$(".hairloss #_3").hide();
	});

	$(".hairloss #_3no #no_3").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_3no").hide();
	});

	$(".hairloss #_4 #yes_4").click(function() {
		alert("sent");
	});
	$(".hairloss #_4 #no_4").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_4").hide();
	});
	$(".hairloss #_44 #no_4").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_44").hide();
	});

	/*********/

	/***headace*/

	$(".headace #_1 #begin").click(function() {
		$(".headace #_2").show();
		$(".headace #_1").hide();
	});

	$(".headace #_2 #yes_2").click(function() {
		$(".headace #_3").show();
		$(".headace #_2").hide();
	});
	$(".hairloss #_3no #no_4").click(function() {
		$(".hairloss #_3").show();
		$(".hairloss #_3no").hide();
	});
	$(".headace #_3no #no_3").click(function() {
		$(".headace #_22").show();
		$(".headace #_3no").hide();
	});
	$(".headace #_3no #no_65").click(function() {
		// $(".headace #_22").show();
		// $(".headace #_3no").hide();
		$alert("hello");
	});
	$(".headace #_2 #no_2").click(function() {
		$(".headace #_22").show();
		$(".headace #_2").hide();
	});

	$(".headace #_22 #yes_2").click(function() {
		$(".headace #_33").show();
		$(".headace #_22").hide();
	});

	$(".headace #_22 #no_2").click(function() {
		$(".headace #_3no").show();
		$(".headace #_22").hide();
	});

	$(".hairloss #_3 #yes_3").click(function() {
		$(".hairloss #_4").show();
		$(".hairloss #_3").hide();
	});

	$(".headace #_33 #yes_3").click(function() {
		$(".headace #_4").show();
		$(".headace #_33").hide();
	});

	$(".headace #_3 #no_3").click(function() {
		$(".headace #_2").show();
		$(".headace #_3").hide();
	});

	$(".hairloss #_4 #yes_4").click(function() {
		alert("sent");
	});
	$(".headace #_4 #no_4").click(function() {
		$(".headace #_33").show();
		$(".headace #_4").hide();
	});

	$(".headace #_33 #no_3").click(function() {
		$(".headace #_44").show();
		$(".headace #_33").hide();
	});

	$(".headace #_44 #no_4").click(function() {
		$(".headace #_33").show();
		$(".headace #_44").hide();
	});

	/*******/

	/********standing*/


	$(".standing_rotor #_1 #begin").click(function() {
		$(".standing_rotor #_2").show();
		$(".standing_rotor #_1").hide();
	});




	/********/


	/***DryEyeandMouth*/

	$(".dry_eye #_1 #begin").click(function() {
		$(".dry_eye #_2").show();
		$(".dry_eye #_1").hide();
	});

	$(".dry_eye #_2 #yes_2").click(function() {
		$(".dry_eye #_3").show();
		$(".dry_eye #_2").hide();
	});
	$(".dry_eye #_3no #no_3").click(function() {
		$(".dry_eye #_4").show();
		$(".dry_eye #_3no").hide();
	});




	$(".dry_eye #_22 #no_2").click(function() {
		$(".dry_eye #_5").show();
		$(".dry_eye #_22").hide();
	});

	$(".dry_eye #_3 #yes_3").click(function() {
		$(".dry_eye #_5").show();
		$(".dry_eye #_3").hide();
	});

	$(".dry_eye #_5 #yes_5").click(function() {
		$(".dry_eye #_22").show();
		$(".dry_eye #_5").hide();
	});



	$(".dry_eye #_3 #no_3").click(function() {
		$(".dry_eye #_33").show();
		$(".dry_eye #_3").hide();
	});

	$(".dry_eye #_4 #yes_4").click(function() {
		$(".dry_eye #_3no").show();
		$(".dry_eye #_4").hide();
	});


	$(".dry_eye #_5 #no_5").click(function() {
		$(".dry_eye #_4").show();
		$(".dry_eye #_5").hide();
	});


	/*******/

	/********eyeout*/


	/******/

	/********cough*/

	$(".dry_eye #_5 #no_6").click(function() {
		$(".dry_eye #_3").show();
		$(".dry_eye #_5").hide();
	});
	$(".dry_eye #_2 #yes_3").click(function() {
		$(".dry_eye #_4").show();
		$(".dry_eye #_2").hide();
	});

	/********/
	
	/********chestpain*/

	$(".dry_eye #_2 #yes_1").click(function() {
		$(".dry_eye #_44").show();
		$(".dry_eye #_2").hide();
	});
	$(".dry_eye #_44 #no_3").click(function() {
		$(".dry_eye #_2").show();
		$(".dry_eye #_44").hide();
	});

	/********/
});

// var galleryO = $("#gallery").offset().top;
// $(window).scroll(function(){

// var wScrol = $(window).scrollTop();

//     if(wScrol > galleryO)
//         {
//     $(".change").css("backgroundColor","gray")
//     $("#btnUp").fadeIn(500)
//         }
//     else
//         {
//     $(".change").css("backgroundColor","transparent")
//     $("#btnUp").fadeOut(500)

//         }

// })

// $("#btnUp").click(function(){

//     $("html,body").animate({scrollTop:'0'},1000)
// })

// $("a").click(function(){

//    var href =  $(this).attr("href");
//   var off =   $(href).offset().top

//     $("html,body").animate({scrollTop:off},1500)

// })

// $("#options-container i").click(function(){
//     $(".options").toggle()
// })

// var lis = $(".options ul li")

// lis.eq(0).css("backgroundColor","tan")
// lis.eq(1).css("backgroundColor","teal")
// lis.eq(2).css("backgroundColor","orange")
// lis.eq(3).css("backgroundColor","#09c")
// lis.eq(4).css("backgroundColor","red")

// lis.click(function(){

//   var bgColor = $(this).css("backgroundColor")

//   $("*").css("color",bgColor)
//   //$("*").css("backgroundColor",bgColor)

// })

// $(".item").click(function(){
//    var hany =  $(this).attr("src") // getter
//    $("#mainImg").attr("src",hany)// setter
// })

// $(".options img").click(function(){
//    var imgSrc =  $(this).attr("src")
//    $("#home").css("backgroundImage","url("+imgSrc+")")
// })

// var typed = new Typed('.test1', {
//   strings: ["i'm Front-end Developer.", "i'm PHP Developer","web design and development"],
//   typeSpeed:10,
//   loop:true
// });

// new WOW().init();

// $('.owl-carousel').owlCarousel({
//     loop:true,
//     margin:10,
//     nav:true,
//     responsive:{
//         0:{
//             items:1
//         },
//         600:{
//             items:3
//         },
//         1000:{
//             items:5
//         }
//     }
// })
