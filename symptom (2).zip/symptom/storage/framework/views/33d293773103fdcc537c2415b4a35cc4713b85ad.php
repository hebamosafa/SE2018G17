<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم القدم
    <br>
    توقف عما تفعله، واتصل بطبيبك الان، او اذهب الى قسم الطوارئ بالمستشفى القريب منك. بالرغم من ان هذا قد يتضح انه ليس شيئا خطيرا، الا ان اعراضك يمكن ان تكون مرتبطة بعدوى في المفاصل، او الجلد، او انسجة القدم الاخرى. وعدوى القدم هي شيء خطير، ولا سيما اذا كنت تعاني من السكري، او ضعف الدورة الدموية. واذا اتضح انك لا تعاني من عدوى، ارجع الى هذا الدليل؛ لتعرف المزيد عن الاسباب الاكثر شيوعا لالم القدم.
		<div id="demo" class="collapse">

		</div>
   
    <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <br>
      <br>
    
	
  </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>