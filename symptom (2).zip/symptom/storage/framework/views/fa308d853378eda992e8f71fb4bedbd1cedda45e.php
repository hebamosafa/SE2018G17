<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
 الامساك
  <br>

اعراضك ربما تكون اشارة لحالة طارئة!

هذه الاعراض عندما  تظهر مع الامساك، يمكن ان تمثل مشكلة طبية تحتاج الى رعاية عاجلة، مثل: انحشار البراز او سبب اخر لانسداد الامعاء. انحشار البراز هو تراكم كبير للبراز الصلب الذي لا يتحرك.

 

اذا كانت اعراضك جديدة او شديدة، ننصحك بالخروج من هذا الدليل والاتصال بطبيبك الان من اجل التقييم العاجل
		
	
 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
    <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
  </div>
	
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>