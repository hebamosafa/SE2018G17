<?php $__env->startSection('content'); ?>

<?php if(empty($keyword)): ?> 

    <div class="alert alert-danger" role="alert">
  write something in search field!
</div>  



<?php else: ?>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




    





<div class="col-md-4 my-3 text-center table-bordered">
<div class=" " >
<a href="<?php echo e(url('/post/show'.'/'.$post->id)); ?>">

<img class="img-fluid" style="height:300px;width:300px;"  src="<?php echo e(asset('/assets/images/posts'.'/'.$post->image)); ?>">
</a>

</div>
</div>

<div class="col-md-8 my-3  text-right table-bordered">
<a href="<?php echo e(url('/post/show'.'/'.$post->id)); ?>">
<h5 class="pt-3"><?php echo e($post->title); ?> </h5>
</a>
<hr class="py-3">
......<?php echo e(substr($post->postdescription, 0,50)); ?>

 <a style="color:black" href="<?php echo e(url('/post/show'.'/'.$post->id)); ?>">


<p style="color:black">
إقرأ المزيد
</p>
</a>

</div>
<hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>