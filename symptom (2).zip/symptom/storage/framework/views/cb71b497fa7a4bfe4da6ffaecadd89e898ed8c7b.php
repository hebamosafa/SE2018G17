<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger" >
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php echo Form::open(['url'=>'post/storePost','enctype'=>'multipart/form-data']); ?>



    <div class="form-group">
    <label for="exampleInputEmail1">title</label>
    <input type="text" class="form-control"   name="title" placeholder="Enter post title" value="<?php echo e(old('title')); ?>">
        

</div>






<div class="form-group">
    <label for="exampleInputEmail1">description:</label>
<textarea name="postdescription" class="form-control" placeholder="must be more than 100 character" ><?php echo e(old('postdescription')); ?></textarea>
</div>


<div class="form-group">
    <label for="exampleInputEmail1">tag:</label>
<textarea name="posttag" class="form-control" ><?php echo e(old('posttag')); ?></textarea>
</div>



<div class="form-group">
    <label  for="file">image:</label>
<input name="image" type="file" accept="image/*" class="form-control" />

</div>

        
        

<button type="submit" class="btn btn-primary">Submit</button>
<?php echo Form::close(); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>