<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
      		
        تساقط الشعر

  <br>
  قد يشير تساقط الشعر المصاحب لتغيرات في شعر الراس الى وجود مجموعة من الحالات، تعرف باسم تساقط الشعر التندبي يسقط الشعر بسبب تلف بصيلات الشعر (الثقوب الدقيقة التي في الجلد، التي ينمو منها الشعر).

ربما يكون هذا بسبب تفاعل حساسية او تفاعل لمنتجات الشعر، مثل: صبغة الشعر او شامبو جديد.
 
</p>
            

		</div>
   
    <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
  </div>
		
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>