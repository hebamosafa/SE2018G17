<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الم اليد
    <br>
.التشخيص الاكثر احتمالا هو الالتواء
:اما الان، من المحبذ اتباع النصائح التالية
.الراحة: تجنب استخدام يدك كلما امكن لمدة يوم او يومين على الاقل*
.الثلج: وضع كيس خضروات مثلج ملفوف بفوطة يمكنه ان يقلل التورم في اول 24 ساعة*
.الضغط: ربط رباط مرن على التورم ولكن تجنب الربط بقوة شديدة*
.الرفع: احتفظ بيدك مرتفعة في اول 24 ساعة، هذا يمكن ان يقلل الورم ايضا*

</p>
            
		<div id="demo" class="collapse">

		</div>
   
    
	
  </div>

<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>