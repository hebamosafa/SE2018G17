<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    افرازات العين
    <br>
يمكن ان تكون اعراضك بسبب تفاعل تحسسي. اطلب الرعاية العاجلة فورا.

	
	</p>
            
		
		    
	
        
      <br>
      <br>
    
	
  </div>
  <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>