<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الامساك
  <br>
  
		تاتي اعراض الامساك من بطء او تعثر حركة البراز عبر القولون، المستقيم او الشرج. الاشخاص الذين يعانون من امساك حقيقي يعانون عادة من واحدة من الاعراض التالية: الحاجة الى اعتصار (الانقباض بقوة) العضلات في البطن او الحوض من اجل التبرز. براز صلب او متكتل. الرغبة الملحة في التبرز التي تقود الى عدم التبرز بشكل ناجح. اقل من ثلاث مرات تبرز في الاسبوع. الانتفاخ في البطن. الاحساس بانسداد المستقيم اثناء التبرز. الحاجة الى دفع اصابعك داخل المستقيم مقابل الجلد القريب من المستقيم. الشعور انك لم تفرغ المستقيم بعد التبرز تماما
<br><br>
بالاجابة على سلسلة صغيرة من الاسئلة، ستسمح لنا ان نقدم نصيحتنا لك شخصيا
<br>
:الاعراض التالية ربما تشير الى احد المضاعفات المعقدة للامساك، مثل التوقف التام للبراز

الغثيان<br>
القيء<br>
الم البطن الشديد
تسرب البراز او الاسهال (بالرغم من اعراض الامساك الواضحة خلال اخر 24 ساعة ايضا)<br>
رغبة ملحة مستمرة في تحريك امعائك<br>
				<br><br>
				
				هل عانيت اي من هذه الاعراض خلال اخر 24 ساعة؟
				
 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
    <a href="<?php echo e(url('/b11')); ?>">
      <button  id="b1" class="btn btn-primary medium" data-toggle="collapse" data-target="#demo">نعم، أنا أعاني من واحد أو أكثر من هذه الأعراض	 </button></a>
        <br>
      
	  <br>
    <a href="<?php echo e(url('/b12')); ?>">
      <button  id="b1" class="btn btn-primary medium" data-toggle="collapse" data-target="#demo">لا، أنا لا أعاني من هذه الأعراض</button></a>
        
		
	
  </div>
	</div>	
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>