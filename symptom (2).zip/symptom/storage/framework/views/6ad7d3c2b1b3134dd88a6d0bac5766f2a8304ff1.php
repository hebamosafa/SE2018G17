<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
السعال و البرد
            
    <br>
            
بما انك تخرج دما مع السعال، فهناك احتمال انك تعاني من حالة خطيرة في الرئة مثل السرطان. ستحتاج الى مراجعة طبيبك، كي يتمكن من فحصك، يمكن عمل اشعة سينية. اذا كنت تعاني من ضيق في التنفس او اذا كنت تخرج دما مع السعال اكثر من عدة ملاعق، يجب ان تتوجه الى قسم الطوارئ الطبية.

المرض الاكثر شيوعا الذي يجعل الشخص يخرج دما مع السعال، هو التهاب الشعب الهوائية الحاد. هذه هي عدوى تكون بسبب فيروس عادة، هي ليست خطيرة عند معظم الاشخاص. رغم ذلك، فسرطان الرئة هو تفسير محتمل ايضا، يجب اجراء اشعة سينية للصدر. بعض الناس الذين يخرجون دما يحتاجون الى اختبارات اضافية، مثل: الاشعة المقطعية او اجراء "منظار الشعب الهوائية". منظار الشعب الهوائية يتضمن وضع كاميرا في نهاية اداة ضيقة مرنة داخل المسارات الهوائية؛ كي يتم فحصها.

ارسل نتيجة التشخيص الى      
      </p>
            
        
      <br>
      <br>
    
	
  </div>
  <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>