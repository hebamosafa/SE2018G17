<?php $__env->startSection('content'); ?>

<div class="col-md-12">

<div class="  text-capitalize text-center my-3">

	<i><h1><?php echo e($diagnosisDescriptionName); ?></h1></i>

	<?php $__currentLoopData = $diagnosisDescriptionss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnosisDescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


	<div id="_1" class="flex-wrap py-4">
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3"><?php echo e($diagnosisDescription->description); ?>

		</p> 


		<?php if($diagnosisDescriptionName == 'الامساك عند الكبار'): ?>
		<a href="<?php echo e(url('/b1')); ?>" style="color:white;">
		<button id="begin" class="btn btn-success">
		لنبدأ
			</button>
			</a>
			
			<?php endif; ?>


		<?php if($diagnosisDescriptionName == 'الاسهال'): ?>
		<a href="<?php echo e(url('/b2')); ?>" style="color:white;">
		<button id="begin" class="btn btn-success">
		لنبدأ
			</button>
			</a>
			
			<?php endif; ?>




		

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<div class="text-left" class="btn btn-danger">

<a href="<?php echo e(URL::previous()); ?>

		 " class="btn btn-default btn-lg">
	<span><i class="fas fa-arrow-left"></i></span>
	إبدأ تشخيص جديد</a>  
</div>

<!-- for container -->
</div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>