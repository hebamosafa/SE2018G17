<?php $__env->startSection('content'); ?>

<div class="col-md-12">

<div class="text-left" class="btn btn-danger">

<a href="<?php echo e(URL('/home')); ?>

" class="btn btn-default btn-lg">
<span><i class="fas fa-arrow-left"></i></span>
تشخيص جديد</a>  
</div>


<div class=" text-capitalize text-center my-4">


<table class="table">


<i><h1 class="pb-3"><?php echo e($diagnosisName); ?></h1></i>



   
<?php $__currentLoopData = $diagnosis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnosiss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    
    
<?php if($diagnosisName == "العين"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription2'.'/'.$diagnosisanalysisNameEyes=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>

    
<?php if($diagnosisName == "أنف و أذن و حنجرة"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription3'.'/'.$diagnosisanalysisNameNose=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>

    
<?php if($diagnosisName == "الصدر والظهر"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription4'.'/'.$diagnosisanalysisNameChest=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>
<?php if($diagnosisName == "الذراعين واليدين"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription5'.'/'.$diagnosisanalysisNameElbow=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>
<?php if($diagnosisName == "الساقين"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription6'.'/'.$diagnosisanalysisNameLegs=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>
<?php if($diagnosisName == "البطن و الحوض"): ?>

<tr><td><a href="<?php echo e(url('/diagnosisdescription'.'/'.$diagnosisanalysisNameLegs=$diagnosiss->name)); ?>"  class="btn btn-info"><?php echo e($diagnosiss->name); ?></a></td></tr>


<?php endif; ?>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    </table>


</div>




<div class="text-left" class="  pb-4">

<a href="<?php echo e(URL::previous()); ?>

" class="btn btn-danger btn-lg ">
<span><i class="fas fa-arrow-left"></i></span>
رجوع</a>  
</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>