<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الاسهال
  <br>
بعض انواع العدوى الاكثر خطورة، التي يمكن ان تؤدي الى اسهال، هي اقل احتمالا في حالتك؛ لانك لا تعانين من دم او صديد في برازك. بالرغم من ذلك، فان العدوى هي السبب الاكثر احتمالا لاسهالك الحاد. معرفة الاطعمة التي تناولتها حديثا، التي يمكن ان تكون ملوثة بالبكتريا او الطفيليات يمكن ان تكون مفيدة</h2>
				
</p>
            
		<div id="demo" class="collapse">

		</div>
   
      <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	
  </div>
	</div>	
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>