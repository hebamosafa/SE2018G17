<?php $__env->startSection('content'); ?>



<div class="text-left" class="btn btn-danger">

<a href="<?php echo e(URL('/home')); ?>

" class="btn btn-default btn-lg">
<span><i class="fas fa-arrow-left"></i></span>
تشخيص جديد</a>  
</div>

<div class="container text-capitalize text-center my-4">

<h3 class="pb-3">أختر جزء من الجسم</h3>

<table class="table">
<!-- 
$uniques = array();
foreach ($countries as $c) {
    $uniques[$c->code] = $c; // Get unique country by code.
}

dd($uniques); -->



<?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><a href="<?php echo e(url('/diagnosis'.'/'.$diagnosisanalysis=$symptom->tag)); ?>" class="btn btn-info"><?php echo e($symptom->tag); ?></a></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
</div>




<div class="text-left" >

<a href="<?php echo e(URL::previous()); ?>

" class="btn btn-danger btn-lg">
<span><i class="fas fa-arrow-left"></i></span>
رجوع</a>  
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>