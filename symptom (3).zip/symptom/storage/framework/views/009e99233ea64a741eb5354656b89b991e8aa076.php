<?php $__env->startSection('content2'); ?>

<?php if(empty($keyword)): ?> 

    <div class="alert alert-danger" role="alert">
  write something in search field!
</div>  



<?php else: ?>

<div class="blog_area">
        <div class="container">
            <div class="row  text-center">
                <div class="col-lg-8">
                    <div class="blog_left_sidebar">


                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <a style="color:black;" href="<?php echo e(url('/post/show'.'/'.$post->id)); ?>">


                        <article class="row blog_item">
                            <div class="col-md-3">
                                <div class="blog_info text-right">
                                    <div class="post_tag">
                                        <a class="" style="coloe:black; font-size:18px;" href="#">قسم: <?php echo e($post->posttag); ?>


                                      </a>
                                    </div>
                                   
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="blog_post">
                                <a style="color:black;" href="<?php echo e(url('/post/show'.'/'.$post->id)); ?>">

                                    <img class="w-100 h-75" style="max-width:100%;" src="<?php echo e(asset('/assets/images/posts'.'/'.$post->image)); ?>">

                                    <div class="blog_details">
                                        <a href="single-blog.html">
                                            <h2>
                                            <?php echo e($post->title); ?>

                                                                                    </h2>
                                        </a>
                                        <p>
                                        ......<?php echo e(substr($post->postdescription, 0,100)); ?>


                                        
                                        </p>
                                        <a href="single-blog.html" class="blog_btn">View More</a>
                                    </div>
                                    <hr>
                                </div>
                            </div>
                        </article>
</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </div>
                    </div>
                    </div>
                   <div>









<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>