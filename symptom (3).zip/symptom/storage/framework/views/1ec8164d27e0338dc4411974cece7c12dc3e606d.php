<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
      		
جفاف العين و الفم
	<br>
اذا كنت تعاني من جفاف العين وجفاف الفم، يمكن ان يكون السبب هو مرض يسمى متلازمة شوغرين (sjogren's syndrome)، وهو مرض مناعي يعتقد فيه ان جهاز المناعة بالجسم، يهاجم انسجة معينة في الجسم، متضمنة الغدد التي تنتج الدموع واللعاب. السؤال التالي يسال عن مميزات هذا المرض التي تجعله اكثر احتمالا في حالتك.

الى جانب جفاف العين وجفاف الفم، توجد اشياء اخرى شائعة عند الاشخاص الذين يعانون من  متلازمة شوغرين.

اضافة الى جفاف العين وجفاف الفم، هل تعاني من واحدة او اكثر من الاتي؟

تورم الغدة النكفية - غدة تقع في جانب الوجه اسفل وامام الاذن مباشرة.
نتائج سلبية لاختبارات انتاج الدموع، او اللعاب التي قام بها طبيبك، طبيب العيون او طبيب الانف والاذن والحنجرة عادة. هذه الاختبارات، تشمل: اختبار شيرمر (Schirmer's test)، اختبار صبغة وردية البنغال (Rose-Bengal staining)، اختبار تدفق اللعاب العادي والمحفز وتحليل عينة من الشفة.
اختبار الاجسام المضادة للمضاد النووي في الدم ايجابي (غير طبيعي)، لا سيما مع احد انواع الاجسام المضادة، للمضاد النووي المسمى anti-Ro.
اذا لم تكن متاكدا انك تعاني من اي من هذه الامور، يمكنك الحصول على المعلومات من عيادة طبيبك. 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
    <a href="<?php echo e(url('/eye11')); ?>">
      <button  id="b1" class="btn btn-primary medium" data-toggle="collapse" data-target="#demo">	نعم أنا أعاني من واحده أو أكثر من هذه الأعراض  </button></a>
        
      <br>
      <br>
 
		
	
  </div>
		
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>