<?php $__env->startSection('content'); ?>



<div class="container text-capitalize text-center my-4">

<i><h1>choose body part</h1></i>

<table class="table">
    <tr><td><a href="Hairlossinwomen.html">Hair loss</a></td></tr>
    <tr><td><a href="Headaches.html">Headaches</a></td></tr>
    
</table>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>