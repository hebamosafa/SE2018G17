<?php $__env->startSection('content'); ?>





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
      		
  ألم القدم
  <br>
  هذه اخبار جيدة! ربما تعاني من الم الركبة بسبب التواء بسيط للاربطة او العضلات الذي سوف يتحسن مع مرور الوقت، بالعلاجات التي يمكن ان تقوم بها بنفسك. لكن مرة اخرى يمكن ان يكون من الصعب التنبؤ بهذه الاشياء. جرب العلاجات التحفظية
الراحة: تجنب الانشطة التي تعتقد انها ربما تثير الم الركبة
الثلج
الدعامة\الرباط
مسكنات الالم التي دون وصفة طبية مثل: اسيتامينوفين او ايبوبروفين إلا إذا نصحك الطبيب بتجنبها
</p>
      
<br>
   <?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	
  </div>
		
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>