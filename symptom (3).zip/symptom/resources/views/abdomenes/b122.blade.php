@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
 الامساك
  <br>

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
 الامساك
  <br>

لا يبدو ان الامساك لديك كان بسبب اصابة للاعصاب التي في المخ او الحبل الشوكي. رغم ذلك، هناك ايضا نهايات عصبية في الامعاء ربما تكون مؤثرة على وظيفة الامعاء لديك، ووظيفة هذه الاعصاب يجب ان توضع في الحسبان. هناك سبب شائع للامساك، وهو تلف الاعصاب الموضعية في الامعاء، وهو ما يعرف باسم الاعتلال العصبي اللاارادي. هذه واحدة من المضاعفات الشائعة لمرض السكري <br>(diabetes) 
				
 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
		
	
  </div>
	
    
@endsection
		
	
 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
		
	
  </div>
	
    
@endsection