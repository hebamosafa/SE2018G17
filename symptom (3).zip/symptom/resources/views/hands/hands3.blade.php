@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
 مشاكل الاظافر
  <br>
  :يمكن ان تحدث مشاكل الاظافر لعدد من الاسباب


.التهاب الجلد، الظفر الناشب (ingrown nail) والصدفية هي من بين الاسباب الاكثر شيوعا
.لكن العدوى هي من بين الاسباب الاكثر خطورة. يجب تقييم اي مشكلة في الاظافر، لا تتحسن مع مرور الوقت بواسطة الطبيب 


<br><br>

 
</p>
            
</div>
		</div>
   @include('layouts.form')
   
        
		

    
@endsection