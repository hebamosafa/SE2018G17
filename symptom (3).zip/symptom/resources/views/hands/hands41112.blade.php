@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
   
    <br>
العامل الروماتويدي الايجابي
<br>
وهل لاحظت، او اخبرك احد باي من التالي: · تغيرات في اللون في جلد اصابع يديك، و/او قدميك بسبب البرد (تسمى ظاهرة رينود Raynaud's) · شد جلد اصابعك، ولمعانه · جفاف العينين، و/او جفاف الفم · طفح جلدي مزمن في الوجه، او فروة الراس، او الاطراف · قروح في الفم متعددة ومتكررة · حساسية للشمس (مع حمى، او طفح جلدي عند التعرض للشمس لفترة وجيزة) · ارتشاح غشاء الرئة Pleurisy (الم في الصدر مع التنفس، او سائل حول الغشاء المحيط بالرئة يظهر في الاشعة السينية) · تشنجات (او صرع) · بروتين، او دم في البول، او مرض اخر في الكلية · انخفاض عدد خلايا الدم · اجسام مضادة اخرى ايجابية، تسمى الاجسام المضادة النووية Antinuclear Antibody) ANA)


</p>
            
		<div id="demo" class="collapse">

		</div>
   
   
    
	
  </div>

@include('layouts.form')
		
    
@endsection