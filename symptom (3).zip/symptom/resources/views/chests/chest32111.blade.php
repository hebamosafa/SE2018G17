

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم أسفل الظهر
    <br>

	
وفقا لاجاباتك، غالبا الم مرفقك هو بسبب التهاب اوتار العضلات (tendonitis)، التواء الاربطة (sprain) او ربما بسبب انشطة حديثة. يجب ان يتحسن هذا الالم مع مرور الوقت.

لتخفيف الالم تجنب الاستخدام الزائد للظهر، استرح قليلا عند الضرورة (لكن تجنب الراحة الكاملة في الفراش لاكثر من يوم او يومين؛ لانه ثبت انها ليست بالضرورة مجدية) وتجنب الانشطة التي ربما تثير المك في المقام الاول.

هناك ادوية الالم التي تباع دون وصفة طبية، العلاجات الموضعية (مثل ايسي هوت - Icy Hot او بينجاي - BenGay) او وضع الثلج التي ربما تساعد على تخفيف الالم ايضا.

اذا ساءت الاعراض او لم تتحسن، قم باستشارة طبيبك.

</p>
            

      <br>
      <br>
    
	
  </div>


 @include('layouts.form')

    
@endsection