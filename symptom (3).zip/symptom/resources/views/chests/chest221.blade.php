

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    خفقان القلب
    <br>
اتصل بعيادة طبيبك، من اجل ترتيب موعد.

اذا عاد خفقان القلب مع احد الاعراض او اكثر، فلا تنتظر، سوف تحتاج الى رعاية طبية فورية.

اكثر الطرق امانا هو الاتصال برقم الطوارئ الخاص ببلدك.

ارسل نتيجة التشخيص الى
	</p>
            
		
        
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection