

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم الصدر
    <br>
اتصل برقم الطوارئ الخاص ببلدك فورا. قد تعاني من نوبة قلبية. اسال مسؤول الطوارئ اذا كانت هناك حاجة لتتناول اسبرين الان.

ارسل نتيجة التشخيص الى
</p>
            
		
      <br>
      <br>
    
	
  </div>
    @include('layouts.form')



		
    
@endsection