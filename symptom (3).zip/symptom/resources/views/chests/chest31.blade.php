

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم أسفل الظهر
    <br>

	
	وفقا لاعراضك، ربما تعاني من عدوى، كسر او سبب خطير اخر لالم ظهرك.

بالرغم من ان معظم الناس الذين يعانون من هذه الاعراض، يتضح في نهاية المطاف عدم وجود شيء خطير عندهم، الا انه بشكل عام تكون فكرة جيدة ان تطلب الرعاية الطبية للتاكد.

اتصل بطبيبك او اذهب الى قسم الطوارئ الان من اجل التقييم!

ارسل نتيجة التشخيص الى

</p>
            

      <br>
      <br>
    
	
  </div>


 @include('layouts.form')

    
@endsection