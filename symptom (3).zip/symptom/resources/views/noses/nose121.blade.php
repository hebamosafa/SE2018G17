

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    السعال و البرد
    <br>
	
	اعراضك ترجح وجود تورم كبير في الحلق. يمكن ان يسوء تورم الحلق سريعا، اذا كان بسبب خراج بجوار اللوزة (تجمع صديد في الحلق بسبب عدوى بكتيرية) او حساسية. من فضلك رتب لزيارة طبيبك اليوم او اذهب الى قسم الطوارئ.

انقر بالاسفل من اجل المزيد من المعلومات عن:

التهاب الحلق (التهاب البلعوم)
تفاعلات الحساسية الشديدة (الحساسية المفرطة)
ارسل نتيجة التشخيص الى
	</p>
            
		
      <br>
      <br>
    
	
  </div>
  @include('layouts.form')

    
@endsection