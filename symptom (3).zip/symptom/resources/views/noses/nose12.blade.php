

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    السعال و البرد
    <br>
لقد علمنا ان العرض الاكثر ازعاجا بالنسبة لك هو التهاب الحلق. في الحالات الشديدة جدا يمكن ان يصاحب التهاب الحلق تورم خطير في اللوزتين او النسيج المجاور، هذا يمكن ان يؤدي لخطر حدوث انسداد المسار الهوائي. في هذه الحالة، يجب مراجعة الطبيب للتقييم.

قم بمراجعة الاسئلة الثلاثة التالية:

هل لعابك يسيل، لانك غير قادر على ابتلاع لعابك بسهولة؟
هل تعاني من اصوات غير معتادة مع التنفس؟
هل تشعر ان حلقك ينسد؟
		<div id="demo" class="collapse">

		</div>
   
    <a href="nose121">
      <button  id="b1" class="btn btn-primary medium" data-toggle="collapse" data-target="#demo"> نعم أعاني من واحده أو أكثر من هذه الأعراض</button></a>
        
      <br>
      <br>
    
	
  </div>

    
@endsection