

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    ألم الأذن عند الكبار
    <br>

	اتصل بطبيبك. ربما انت تعاني من عدوى في قناة الاذن التي تمتد للخارج، لدرجة يمكنك رؤيتها. بديلا من ذلك، ربما يكون هذا عبارة عن عدوى في الجلد، تسمى التهاب الهلل (cellulites). كلا الحالتين تتطلبان اهتماما فوريا وعلاجا بالمضادات الحيوية عادة.

ارسل نتيجة التشخيص الى

</p>
            
		
        
      <br>
      <br>
      @include('layouts.form')

	
  </div>


		
    
@endsection