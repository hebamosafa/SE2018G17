

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
    جفاف العين و الفم
    <br>
حسنا، تلك معلومات مهمة، التهاب جفن العين هو احد اسباب الشعور بجفاف العين؛ لذلك من اجاباتك قد يكون التهاب جفن العين، هو سبب الشعور بجفاف العين لديك. العلاج يبدا عادة بضمادات دافئة على جفن العين والغسيل بصابون خفيف (مثل شامبو الاطفال). قم بمراجعة طبيبك او طبيب العيون الخاص بك؛ لمناقشة هذه الامور وخيارات العلاج الاخرى.



</p>
            
		
   
    
      <br>
      <br>
    
	
  </div>

  @include('layouts.form')

		
    
@endsection