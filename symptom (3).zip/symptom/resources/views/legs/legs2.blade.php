

@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
      		
  ألم القدم
  <br>
  .يؤسفنا ان نسمع انك تعاني من النقرس .هدف هذا الدليل، هو تقديم المعلومات أثناء انتظار التقييم مع الطبيب، أو معلومات إضافية بعد رؤية طبيبك من فضلك الاخذ بعين الاعتبار ان هذا الدليل لا يقصد به ان يكون بديلا للتقييم وجها لوجه مع طبيبك : اولا، بعض المعلومات الاساسية عن الحالة نفسها النقرس هو حالة يحدث فيها التهاب لمفصل، او اكثر بسبب ترسب بلورات حمض اليوريك فيها. وحمض اليوريك هو منتج طبيعي، من الوظائف الطبيعية للجسم، ويزال من الجسم بواسطة الكلى. 
</p>
            
</div>
   
  </div>
		
    
@endsection