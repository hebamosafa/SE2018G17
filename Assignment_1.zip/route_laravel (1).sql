-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- المزود: 127.0.0.1
-- أنشئ في: 08 نوفمبر 2018 الساعة 18:56
-- إصدارة المزود: 5.5.27
-- PHP إصدارة: 7.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `route_laravel`
--

-- --------------------------------------------------------

--
-- بنية الجدول `films`
--

CREATE TABLE IF NOT EXISTS `films` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filmname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filmdescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `max_degree` int(11) NOT NULL,
  `subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=15 ;

--
-- إرجاع أو استيراد بيانات الجدول `films`
--

INSERT INTO `films` (`id`, `filmname`, `filmdescription`, `image`, `created_at`, `updated_at`, `max_degree`, `subtitle`, `custom_id`) VALUES
(1, 'C++', '1st electrical', '1540986350oops-concept-in-cpp.png', '2018-10-14 22:00:00', '2018-10-31 09:45:50', 100, 'sljcnsdjkbckdsjdfcihosdu', 2),
(8, 'CO 1', '2nd electrical', '1540654017oops-concept-in-cpp.png', '2018-10-27 13:26:57', '2018-10-27 13:26:57', 130, '', 3),
(10, 'data stucture & algorithms', '3rd computer', '1540654263Apple-logo-grey-880x625.png', '2018-10-27 13:31:03', '2018-10-27 13:31:03', 140, '', 1),
(11, 'web development', '3rd computer', '1540986284oops-concept-in-cpp.png', '2018-10-31 09:44:44', '2018-10-31 09:44:44', 90, 'kjasgcyjgahbckakhcbjad', 4),
(12, '2 control', '3rd computer', NULL, '0000-00-00 00:00:00', NULL, 250, 'khbhjfhddxfhgbjh', 22),
(13, 'electronics', '1st elec', NULL, NULL, NULL, 179, 'kchvcsjshuvyydc ', 23),
(14, 'Project Management', '3rd computer', '1541189348oops-concept-in-cpp.png', '2018-11-02 18:09:08', '2018-11-02 18:09:08', 120, 'jhwdcuwdiwd', 98);

-- --------------------------------------------------------

--
-- بنية الجدول `grades`
--

CREATE TABLE IF NOT EXISTS `grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `examine_at` date NOT NULL,
  `degree` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=47 ;

--
-- إرجاع أو استيراد بيانات الجدول `grades`
--

INSERT INTO `grades` (`id`, `examine_at`, `degree`, `studentid`, `courseid`, `created_at`, `updated_at`) VALUES
(1, '2018-11-12', 150, 5, 1, '0000-00-00 00:00:00', '2018-11-02 16:34:54'),
(3, '2018-11-23', 90, 3, 32, '0000-00-00 00:00:00', '2018-11-02 13:37:25'),
(4, '2018-11-04', 100, 26, 22, '2018-11-02 13:20:28', '2018-11-02 13:32:18'),
(23, '2018-08-12', 112, 27, 22, '2018-11-02 15:56:54', '2018-11-02 15:56:54'),
(30, '2018-11-29', 109, 12, 3, '2018-11-02 16:36:43', '2018-11-02 16:36:43'),
(32, '2018-11-29', 5, 4, 23, '2018-11-02 16:41:05', '2018-11-02 16:41:05'),
(36, '2018-07-30', 67, 12, 1, '2018-11-02 16:45:25', '2018-11-02 16:45:25'),
(38, '2018-11-21', 122, 27, 22, '2018-11-02 16:48:58', '2018-11-02 16:48:58'),
(43, '2018-11-05', 456, 1, 98, '2018-11-02 18:18:59', '2018-11-02 18:18:59'),
(44, '2018-11-05', 456, 1, 98, '2018-11-02 18:19:46', '2018-11-02 18:19:46'),
(45, '2018-11-05', 456, 1, 98, '2018-11-02 18:22:44', '2018-11-02 18:22:44'),
(46, '2018-11-13', 234, 234, 98, '2018-11-02 18:23:55', '2018-11-02 18:23:55');

-- --------------------------------------------------------

--
-- بنية الجدول `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=13 ;

--
-- إرجاع أو استيراد بيانات الجدول `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2018_10_12_111717_create_films_table', 1),
(10, '2018_10_27_153308_create_students_table', 2),
(11, '2018_10_31_121616_create_grades_table', 3),
(12, '2018_10_31_123139_create_grades_table', 4);

-- --------------------------------------------------------

--
-- بنية الجدول `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('mostafamagico44@gmail.com', '$2y$10$nTrvI.UhGmbyw2aLV.h/OebGQoJ7OaUABvWXz6LH5Ag88lYX.zPCW', '2018-10-16 14:19:20');

-- --------------------------------------------------------

--
-- بنية الجدول `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studentname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=46 ;

--
-- إرجاع أو استيراد بيانات الجدول `students`
--

INSERT INTO `students` (`id`, `studentname`, `created_at`, `updated_at`, `student_id`, `image`) VALUES
(0, 'ahmed', '0000-00-00 00:00:00', NULL, 5, NULL),
(1, 'marco', '2018-10-31 08:03:53', '2018-10-31 09:47:02', 2, '1540986421oops-concept-in-cpp.png'),
(4, 'ezz', '2018-11-20 22:00:00', '2018-11-28 22:00:00', 3, NULL),
(8, 'mostafa', '2018-10-31 08:10:45', '2018-10-31 09:53:17', 4, '1540986796avtr-he-bg-03.jpg'),
(41, 'atef', '2018-11-21 22:00:00', '2018-11-26 22:00:00', 26, NULL),
(42, 'abdelrahman', '2018-11-24 22:00:00', '2018-11-02 08:26:09', 27, NULL),
(43, 'mohamed', '2018-11-02 13:35:05', '2018-11-02 13:35:05', 12, '1541172904avtr-he-bg-03.jpg'),
(45, 'gamal', '2018-11-02 18:16:22', '2018-11-02 18:16:22', 234, NULL);

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`) VALUES
(1, 'mostafa', 'mostafa.hamed1944@gmail.com', NULL, '$2y$10$Ogg2ZaWROE7KO24RCBL/yu4cd9Thd7Zklb9xlgm4rKhAdEDIqUq4O', '7LrbyxhPq9DEQteThn45QlT10er3NxwGGjftT4ELi8x9si1EyycEWNPrSQ0e', '2018-10-16 09:34:40', '2018-10-16 09:34:40', 1),
(2, 'mostafa', 'mostafamagico44@gmail.com', NULL, '$2y$10$NosVfzW8chZr/je6ym3rM.MDLFfzGCXs2F.i4krrs5CI6ggZHfpzO', '3pNcJSXvcsWYYKhqFuFILN1kA7hO0Uk7H9A06YN8TRUccjKPldi4zrMVryoX', '2018-10-16 10:52:34', '2018-10-16 10:52:34', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
