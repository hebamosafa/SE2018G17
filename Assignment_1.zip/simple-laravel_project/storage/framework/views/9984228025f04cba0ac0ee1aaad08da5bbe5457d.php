 

<?php $__env->startSection('title','students'); ?>


<?php $__env->startSection('content'); ?>


<a style="color:#white;font-size:22px;padding-left:20px;" class="btn btn-dark  mb-5" href="<?php echo e(url('/students/create')); ?>">add students </a>


<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5><a style="font-size:42px; text-decoration:none;"  href="<?php echo e(url('/students/show'.'/'.$student->id)); ?>"> 
    <?php echo e($student->studentname); ?>  <br/>
<h3 style="font-size:28px; text-decoration:none; color:#525252;" >id: <?php echo e($student->student_id); ?></h3>
	<p style="color: #f4645f; font-size:18px;">read more...</p>
	<hr/>
	</a></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>