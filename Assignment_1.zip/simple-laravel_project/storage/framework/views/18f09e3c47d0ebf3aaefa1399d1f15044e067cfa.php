<?php $__env->startSection('title','students'); ?>


<?php $__env->startSection('content'); ?>



<table class="table table-bordered table-hover text-center my-5">

	<tr>

		
		<th>student name:</th>
		<th>course name:</th>
		
		<th>degree: </th>

	</tr>


	<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		

		<td><?php echo e($dat->studentname); ?></td>

		<td><?php echo e($dat->filmname); ?></td>

		

		<td><?php echo e($dat->degree); ?></td>


	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	


</table>


<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>