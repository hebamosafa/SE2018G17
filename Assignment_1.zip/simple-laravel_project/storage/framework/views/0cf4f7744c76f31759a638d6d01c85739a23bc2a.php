<?php $__env->startSection('title','student'); ?>


<?php $__env->startSection('content'); ?>


<div style="background-color:#245;" class="gft">
	<a style="color:#894;font-size:22px;" class="p-4" href="<?php echo e(url('/students/edit'.'/'.$student->id)); ?>">Edit</a>
	<a style="color:red;font-size:22px;" href="<?php echo e(url('/students/destroy'.'/'.$student->id)); ?>">Delete</a>

	
</div>


<table class="table table-hover table-bordered text-center my-5">
	<tr>
		
		<th>student name:</th>
		
		<th>id:</th>
	</tr>
	<tr>
		
		<td><?php echo e($student->studentname); ?></td>
		
		<td><?php echo e($student->student_id); ?></td>
	</tr>

</table>

<hr/>
<!--
<img src="<?php echo e(asset('/assets/images/students'.'/'.$student->image)); ?>">
-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>