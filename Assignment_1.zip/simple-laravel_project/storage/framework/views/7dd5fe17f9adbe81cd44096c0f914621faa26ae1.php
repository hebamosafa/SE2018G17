<?php $__env->startSection('title','students'); ?>


<?php $__env->startSection('content'); ?>



	<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-dark" href="<?php echo e(url('/grades/create')); ?>">add students </a>




<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-dark" href="<?php echo e(url('/grades/custom')); ?>">Custom grades view: </a>


<table class="table table-bordered table-hover text-center my-5">

	<tr>

		<th>id: </th>
		<th>student id:</th>
		<th>course id:</th>
		<th>examine at:</th>
		<th>degree: </th>

	</tr>


	<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($data->id); ?></td>

		<td><?php echo e($data->studentid); ?></td>

		<td><?php echo e($data->courseid); ?></td>

		<td><?php echo e($data->examine_at); ?></td>

		<td><?php echo e($data->degree); ?></td>


<!--
		<td><h5><a style="font-size:42px; text-decoration:none;"  href="<?php echo e(url('/grades/show'.'/'.$data->id)); ?>"> 
			show </a></h5></td>
		<td>
-->
		<td>
			<div class="btn-group dropup">
				<button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					more..
				</button>
				<div class="dropdown-menu">
					<a class="dropdown-item" href="<?php echo e(url('/grades/show'.'/'.$data->id)); ?>">show to custom</a>
					
				</div>
			</div>
		</td>

	</tr>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	


</table>


<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>