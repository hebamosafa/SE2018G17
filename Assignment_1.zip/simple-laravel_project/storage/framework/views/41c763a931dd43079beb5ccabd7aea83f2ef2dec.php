 

<?php $__env->startSection('title','Films'); ?>


<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5><a style="font-size:42px; text-decoration:none;"  href="<?php echo e(url('/films/show'.'/'.$film->id)); ?>"> 
    <?php echo e($film->filmname); ?> </a></h5> <br/>
<h3><?php echo e($film->filmdescription); ?></h3> <hr/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>