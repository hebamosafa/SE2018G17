<?php $__env->startSection('title','Films'); ?>


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger" >
	<?php echo e($error); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php echo Form::open(['url'=>array('films/update',$film->id) ,'enctype'=>'multipart/form-data']); ?>



<div class="form-group">
	<label for="exampleInputEmail1">subject:</label>
	<input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="filmname" placeholder="Enter film name" value="<?php echo e($film->filmname); ?>"/>


</div>
<div class="form-group">
	<label for="exampleInputEmail1">subject year</label>
	<textarea name="filmdescription" class="form-control" ><?php echo e($film->filmdescription); ?></textarea>
</div>


<div class="form-group">
	<label for="exampleInputEmail1">max_degree</label>
	<textarea name="max_degree" class="form-control" ><?php echo e($film->max_degree); ?></textarea>
</div>


<div class="form-group">
    <label for="exampleInputEmail1">description</label>
<textarea name="subtitle" class="form-control" ><?php echo e($film->subtitle); ?></textarea>
</div>


<div class="form-group">
    <label for="exampleInputEmail1">id</label>
<textarea name="custom_id" class="form-control" ><?php echo e($film->custom_id); ?></textarea>
</div>






<div class="form-group">
    <label  for="file">image:</label>
<input name="image" type="file" accept="image/*" class="form-control" />

</div>




<button type="submit" class="btn btn-primary">Submit</button>
<?php echo Form::close(); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>