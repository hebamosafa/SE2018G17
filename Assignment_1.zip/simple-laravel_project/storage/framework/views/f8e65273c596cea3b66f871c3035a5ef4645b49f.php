<?php $__env->startSection('title','Film'); ?>


<?php $__env->startSection('content'); ?>


<div style="background-color:#245;" class="gft">
	<a style="color:#894;font-size:22px;" class="p-4" href="<?php echo e(url('/films/edit'.'/'.$film->id)); ?>">Edit</a>
	<a style="color:red;font-size:22px;" href="<?php echo e(url('/films/destroy'.'/'.$film->id)); ?>">Delete</a>


</div>


<table class="table table-hover table-bordered text-center my-5">
	<tr>
		
		<th>subject name:</th>
		<th>subject year:</th> 
		<th>max degree:</th>
		<th>description:</th>
		<th>id:</th>
	</tr>
	<tr>
		
		<td><?php echo e($film->filmname); ?></td>
		<td><?php echo e($film->filmdescription); ?></td> 
		<td><?php echo e($film->max_degree); ?></td>
		<td><?php echo e($film->subtitle); ?></td>
		<td><?php echo e($film->custom_id); ?></td>
	</tr>

</table>

<!--
<h2 style="color:#09c;" class="py-3"><?php echo e($film->filmname); ?></h2> <br/>
<h3><?php echo e($film->filmdescription); ?></h3>
<h5>max degree: <?php echo e($film->max_degree); ?></h5>
<h4>id: <?php echo e($film->id); ?></h4>
-->
<hr/>

<img src="<?php echo e(asset('/assets/images/films'.'/'.$film->image)); ?>">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>