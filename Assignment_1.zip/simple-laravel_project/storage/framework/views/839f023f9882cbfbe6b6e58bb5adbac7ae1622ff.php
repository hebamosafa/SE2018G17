<?php $__env->startSection('title','students'); ?>


<?php $__env->startSection('content'); ?>

	<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-success my-4" href="<?php echo e(url('/grades')); ?>"> <i class="fas fa-arrow-left"></i> back to grades to see your Additions </a>

<div class="alert alert-danger" role="alert">
 if you don't find it, that means you didn't entered matched student id or course id with yours inforamtions! 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>