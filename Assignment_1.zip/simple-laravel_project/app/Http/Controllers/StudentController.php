<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$students=Student::get();
        //dd($films);
        return view('students.index',compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		return view('students.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
		$validator=\Validator::make($request->all(),
                                   [
                'studentname'=>'required|max:191|min:3',
                'student_id'=>'required|max:10000|min:1'
               ,'image'=>'image|max:10240|mimes:jpeg,bmp,png'
								
                                   ]);
        
        
        
        if ($validator->fails()) {
             return redirect('students/create')
                        ->withErrors($validator)
                        ->withInput();
        }

      // if i want use this code, i must out the image required| upward.
		/*
        $image=$request->file('image');
            $imageName = time().$image->getClientOriginalName();
            $img = \Image::make($image->getRealPath());
            $img->resize(350, 350);
          $img->save(public_path().'/assets/images/films/'.$imageName);
		  */
           // $newFilm->img=$imageName;

        
        
        
        //
        $student=new student();
        $student->studentname=$request->studentname;
        
		$student->student_id=$request->student_id;
        //$student->image=$imageName;
        $student->save();
        
        return view('students.show',compact('student'));
    }

    /*
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
		$student=Student::find($id);
        
        return view('students.show',compact('student'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
 * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		$student=Student::find($id);
        
        return view('students.edit',compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		 $student=Student::find($id);
	$student->studentname=$request->studentname;
       
		$student->student_id=$request->student_id;
		/*
		 $image=$request->file('image');
            $imageName = time().$image->getClientOriginalName();
            $img = \Image::make($image->getRealPath());
            $img->resize(350, 450);
            $img->save(public_path().'/assets/images/films/'.$imageName);
		$student->image = $imageName;
		*/
        $student->save();
        
        return redirect('/students/show/'.$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		Student::destroy($id);
        
        return redirect('/students');
    }
	
	
	public function search(Request $request)
    {
        
        $keyword=$request->keyword;
		$students=Student::where('studentname','like','%'.$keyword.'%' , 'or','student_id' ,'like','%'.$keyword.'%' )->get();
        
        return view('students.search',compact('students'));
        
    }
	
	
	
	
	
	
	
	
	
}
