<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Grade;

use App\Film;
use App\Student;
use DB;


class GradeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$datas=Grade::get();
       
        return view('grades.index',compact('$datas'));
    }
	
	
	public function manage()
    {
        //
		/*
	$datas= DB::table('grades')
		
            ->rightJoin('students', 'grades.studentid', '=', 'students.student_id')
            ->leftJoin('films', 'films.custom_id', '=', 'grades.courseid')
			
       ->select('grades.examine_at','grades.degree','grades.studentid','students.student_id','students.updated_at','films.custom_id')
	   */
		$datas=DB::table('grades')
			
			
            
			->join('students','students.student_id','grades.studentid')
			->join('films','films.custom_id','grades.courseid')
			->select('grades.courseid','grades.studentid','grades.examine_at','grades.id','grades.degree','students.student_id','students.studentname','films.filmname')
			
            ->get();
		$cust=$datas;
		return view('grades.index',compact('datas'));
		
		/*echo'<pre>';
		print_r($datas);
		echo'</pre>';
		*/

    }
	
	public function custom()
    {
        //
		
  $datas=DB::table('grades')
			
			
            
			->join('students','students.student_id','grades.studentid')
			->join('films','films.custom_id','grades.courseid')
			->select('grades.courseid','grades.studentid','grades.examine_at','grades.id','grades.degree','students.student_id','students.studentname','films.filmname')
 ->get();
		
		
		 return view('grades.custom',compact('datas'));
    }
	

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
		 return view('grades.create');
    }
	
	 public function show($id)
    {
		 
        //
		 
		 		
  $datas=DB::table('grades')
			
			
            
			->join('students','students.student_id','grades.studentid')
			->join('films','films.custom_id','grades.courseid')
			->select('grades.courseid','grades.studentid','grades.examine_at','grades.id','grades.degree','students.student_id','students.studentname','films.filmname')
 ->get();
		 
		 
		 
        $dat=Grade::find($id);
        
        return view('grades.show',compact('dat'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(request $request)
    {
        //
		$datasr=new grade();
        $datasr->id=$request->id;
        $datasr->examine_at=$request->examine_at;
		$datasr->degree=$request->degree;
		$datasr->studentid=$request->studentid;
		$datasr->courseid=$request->courseid;
        $datasr->save();
        $datas=$datasr;
        return view('grades.success',compact('datas'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
		$dat=Grade::find($id);
        
        return view('grades.edit',compact('dat'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
		 $dat=Grade::find($id);
        $dat->examine_at=$request->examine_at;
        $dat->degree=$request->degree;
		$dat->courseid=$request->courseid;
		$dat->studentid=$request->studentid;
		
		
        $dat->save();
        
        return redirect('/grades/show/'.$id);
    }
	
	


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
		 Grade::destroy($id);
        
        return redirect('/grades');
    }
	
	
	
	public function search(Request $request)
    {
			
  $datar=DB::table('grades')
			
			
            
			->join('students','students.student_id','grades.studentid')
			->join('films','films.custom_id','grades.courseid')
			->select('grades.courseid','grades.studentid','grades.examine_at','grades.id','grades.degree','students.student_id','students.studentname','films.filmname')
 ->get();
	
		
        
        $keyword=$request->keyword;
		$datas=$datar::where('$datas.studentname','like','%'.$keyword.'%' , 'or','$datas.filmname' ,'like','%'.$keyword.'%' )->get();
        
        return view('grades.search',compact('students'));
        
    }
	
	
}
















