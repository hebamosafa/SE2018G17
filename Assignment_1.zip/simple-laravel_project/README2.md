# simple-laravel_project
this project you can add films with register in the site and edit or delete it at any time, this site also has a login page and a custmize register page
