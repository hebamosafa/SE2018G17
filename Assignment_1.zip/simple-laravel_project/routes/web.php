<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('');
});
*/
Route::get('/','FilmController@index');
Route::get('/films','FilmController@index');
Route::get('/films/create','FilmController@create');
Route::post('/films/storeFilm','FilmController@store');
Route::get('/films/show/{id}','FilmController@show');
Route::get('/films/edit/{id}','FilmController@edit');
Route::post('/films/update/{id}','FilmController@update');
Route::get('/films/destroy/{id}','FilmController@destroy');
Route::get('/films/addse','FilmController@addse');
Route::get('/search','FilmController@search');



Route::get('/students','StudentController@index');
Route::get('/students/create','StudentController@create');
Route::post('/students/storeFilm','StudentController@store');
Route::get('/students/show/{id}','StudentController@show');
Route::get('/students/edit/{id}','StudentController@edit');
Route::post('/students/update/{id}','StudentController@update');
Route::get('/students/destroy/{id}','StudentController@destroy');
Route::get('/students/search','StudentController@search');



Route::get('/grades/','GradeController@manage');
Route::get('/grades/custom','GradeController@custom');
Route::get('/grades/create','GradeController@create');
Route::post('/grades/storeFilm','GradeController@store');
Route::get('/grades/show/{id}','GradeController@show');
Route::get('/grades/edit/{id}','GradeController@edit');
Route::post('/grades/update/{id}','GradeController@update');
Route::get('/grades/destroy/{id}','GradeController@destroy');
Route::get('/grades/search','GradeController@search');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');


$this->get('/verify-user/{code}', 'Auth\RegisterController@activateUser')->name('activate.user');




?>

