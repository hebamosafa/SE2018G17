@extends('layouts.app')

@section('title','Films')


@section('content')

@if($errors->any())
@foreach($errors->all() as $error)
<div class="alert alert-danger" >
	{{$error}}
</div>
@endforeach
@endif


{!!Form::open(['url'=>array('films/update',$film->id) ,'enctype'=>'multipart/form-data'])!!}


<div class="form-group">
	<label for="exampleInputEmail1">subject:</label>
	<input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="filmname" placeholder="Enter film name" value="{{$film->filmname}}"/>


</div>
<div class="form-group">
	<label for="exampleInputEmail1">subject year</label>
	<textarea name="filmdescription" class="form-control" >{{$film->filmdescription}}</textarea>
</div>


<div class="form-group">
	<label for="exampleInputEmail1">max_degree</label>
	<textarea name="max_degree" class="form-control" >{{$film->max_degree}}</textarea>
</div>


<div class="form-group">
    <label for="exampleInputEmail1">description</label>
<textarea name="subtitle" class="form-control" >{{$film->subtitle}}</textarea>
</div>


<div class="form-group">
    <label for="exampleInputEmail1">id</label>
<textarea name="custom_id" class="form-control" >{{$film->custom_id}}</textarea>
</div>






<div class="form-group">
    <label  for="file">image:</label>
<input name="image" type="file" accept="image/*" class="form-control" />

</div>




<button type="submit" class="btn btn-primary">Submit</button>
{!!Form::close()!!}





@endsection