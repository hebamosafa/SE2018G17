@extends('layouts.app')

@section('title','Film')


@section('content')


<div style="background-color:#245;" class="gft">
	<a style="color:#894;font-size:22px;" class="p-4" href="{{url('/films/edit'.'/'.$film->id)}}">Edit</a>
	<a style="color:red;font-size:22px;" href="{{url('/films/destroy'.'/'.$film->id)}}">Delete</a>


</div>


<table class="table table-hover table-bordered text-center my-5">
	<tr>
		
		<th>subject name:</th>
		<th>subject year:</th> 
		<th>max degree:</th>
		<th>description:</th>
		<th>id:</th>
	</tr>
	<tr>
		
		<td>{{$film->filmname}}</td>
		<td>{{$film->filmdescription}}</td> 
		<td>{{$film->max_degree}}</td>
		<td>{{$film->subtitle}}</td>
		<td>{{$film->custom_id}}</td>
	</tr>

</table>

<!--
<h2 style="color:#09c;" class="py-3">{{$film->filmname}}</h2> <br/>
<h3>{{$film->filmdescription}}</h3>
<h5>max degree: {{$film->max_degree}}</h5>
<h4>id: {{$film->id}}</h4>
-->
<hr/>

<img src="{{asset('/assets/images/films'.'/'.$film->image)}}">

@endsection