 @extends('layouts.app')

@section('title','Films')


@section('content')


	<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-dark  mb-5" href="{{url('/films/create')}}">add subjects </a>


@foreach($films as $film)
<h5><a style="font-size:42px; text-decoration:none;"  href="{{url('/films/show'.'/'.$film->id)}}"> 
    {{$film->filmname}}  <br/>
<h3 style="font-size:28px; text-decoration:none; color:#525252;">id:  {{$film->custom_id}}</h3> 
	<p style="color: #f4645f; font-size:18px;">read more...</p>
	<hr/></a></h5>
@endforeach 

@endsection