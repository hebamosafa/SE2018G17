@extends('layouts.app')

@section('title','students')


@section('content')



	<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-dark" href="{{url('/grades/create')}}">add students </a>




<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-dark" href="{{url('/grades/custom')}}">Custom grades view: </a>


<table class="table table-bordered table-hover text-center my-5">

	<tr>

		<th>id: </th>
		<th>student id:</th>
		<th>course id:</th>
		<th>examine at:</th>
		<th>degree: </th>

	</tr>


	@foreach($datas as $data)
	<tr>
		<td>{{$data->id}}</td>

		<td>{{$data->studentid}}</td>

		<td>{{$data->courseid}}</td>

		<td>{{$data->examine_at}}</td>

		<td>{{$data->degree}}</td>


<!--
		<td><h5><a style="font-size:42px; text-decoration:none;"  href="{{url('/grades/show'.'/'.$data->id)}}"> 
			show </a></h5></td>
		<td>
-->
		<td>
			<div class="btn-group dropup">
				<button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					more..
				</button>
				<div class="dropdown-menu">
					<a class="dropdown-item" href="{{url('/grades/show'.'/'.$data->id)}}">show to custom</a>
					
				</div>
			</div>
		</td>

	</tr>
	
	@endforeach
	


</table>


@endsection






