 @extends('layouts.app')

@section('title','students')


@section('content')


@foreach($datas as $data)



<h5><a href="{{url('/grades/show'.'/'.$dat->id)}}"> 
    {{$datas->studentname}} </a></h5> <br/>
<h3>{{$datas->studentid}}</h3> <hr/>
@endforeach 

@endsection