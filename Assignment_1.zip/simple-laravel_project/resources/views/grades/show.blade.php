@extends('layouts.app')

@section('title','Grade')


@section('content')



<div style="background-color:#245;" class="gft">
	<a style="color:#894;font-size:22px;" class="p-4" href="{{url('/grades/edit'.'/'.$dat->id)}}">Edit</a>
	<a style="color:red;font-size:22px;" href="{{url('/grades/destroy'.'/'.$dat->id)}}">Delete</a>

</div>


<table class="table table-hover table-bordered text-center my-5">
	
	<tr>

		<th>id: </th>
		<th>student id:</th>
		<th>course id:</th>
		<th>examine at:</th>
		<th>degree: </th>

	</tr>
	
	<tr>
	<td>{{$dat->id}}</td>
		
		<td>{{$dat->studentid}}</td>
		
		<td>{{$dat->courseid}}</td>
		
		<td>{{$dat->examine_at}}</td>
		
		<td>{{$dat->degree}}</td>
	
	</tr>

	
	
</table>

<hr/>


@endsection