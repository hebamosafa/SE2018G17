@extends('layouts.app')

@section('title','students')


@section('content')



<table class="table table-bordered table-hover text-center my-5">

	<tr>

		
		<th>student name:</th>
		<th>course name:</th>
		
		<th>degree: </th>

	</tr>


	@foreach($datas as $dat)
	<tr>
		

		<td>{{$dat->studentname}}</td>

		<td>{{$dat->filmname}}</td>

		

		<td>{{$dat->degree}}</td>


	@endforeach
	


</table>


@endsection






