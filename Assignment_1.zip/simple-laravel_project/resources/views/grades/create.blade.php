@extends('layouts.app')

@section('title','Grades')


@section('content')

@if($errors->any())
@foreach($errors->all() as $error)
<div class="alert alert-danger" >
	{{$error}}
</div>
@endforeach
@endif


{!!Form::open(['url'=>'grades/storeFilm','enctype'=>'multipart/form-data'])!!}








    <div class="form-group">
    <label for="exampleInputEmail1">student id:</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="studentid" placeholder="Enter film name" value="{{old('studentid')}}">
        

</div>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary mb-5" data-toggle="modal" data-target="#exampleModal">
  read before enter student id...
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">read important..</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        please, make sure that you enter an already matched (student id) in your students->(id) 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>




<div class="form-group">
    <label for="exampleInputEmail1">course id:</label>
<textarea name="courseid" class="form-control" >{{old('courseid')}}</textarea>
</div>




<!-- Button trigger modal -->
<button type="button" class="btn btn-primary mb-5" data-toggle="modal" data-target="#exampleModal">
  read before enter course id...
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">read important..</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        please, make sure that you enter an already matched (course id) in your subjects->(id) 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>







<div class="form-group">
    <label for="exampleInputEmail1">examine at:</label>
<input name="examine_at" class="form-control" type="date" />
</div>


<div class="form-group">
    <label for="exampleInputEmail1">degree:</label>
<textarea name="degree" class="form-control" >{{old('degree')}}</textarea>
</div>




<button type="submit" class="btn btn-primary">Submit</button>
{!!Form::close()!!}





@endsection