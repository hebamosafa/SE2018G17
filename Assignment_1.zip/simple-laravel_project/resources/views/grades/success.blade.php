@extends('layouts.app')

@section('title','students')


@section('content')

	<a style="color:white;font-size:22px;padding-left:20px;" class="btn btn-success my-4" href="{{url('/grades')}}"> <i class="fas fa-arrow-left"></i> back to grades to see your Additions </a>

<div class="alert alert-danger" role="alert">
 if you don't find it, that means you didn't entered matched student id or course id with yours inforamtions! 
</div>


@endsection