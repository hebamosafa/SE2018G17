 @extends('layouts.app')

@section('title','students')


@section('content')


<a style="color:#white;font-size:22px;padding-left:20px;" class="btn btn-dark  mb-5" href="{{url('/students/create')}}">add students </a>


@foreach($students as $student)
<h5><a style="font-size:42px; text-decoration:none;"  href="{{url('/students/show'.'/'.$student->id)}}"> 
    {{$student->studentname}}  <br/>
<h3 style="font-size:28px; text-decoration:none; color:#525252;" >id: {{$student->student_id}}</h3>
	<p style="color: #f4645f; font-size:18px;">read more...</p>
	<hr/>
	</a></h5>
@endforeach 

@endsection