@extends('layouts.app')

@section('title','students')


@section('content')

@if($errors->any())
@foreach($errors->all() as $error)
<div class="alert alert-danger" >
	{{$error}}
</div>
@endforeach
@endif


{!!Form::open(['url'=>array('students/update',$student->id) ,'enctype'=>'multipart/form-data'])!!}


<div class="form-group">
	<label for="exampleInputEmail1">student name:</label>
	<input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="studentname" placeholder="Enter student name" value="{{$student->studentname}}"/>


</div>
<div class="form-group">
    <label for="exampleInputEmail1">id</label>
<textarea name="student_id" class="form-control" >{{$student->student_id}}</textarea>
</div>









<button type="submit" class="btn btn-primary">Submit</button>
{!!Form::close()!!}





@endsection