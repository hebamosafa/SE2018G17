 @extends('layouts.app')

@section('title','students')


@section('content')


@foreach($students as $student)



<h5><a href="{{url('/students/show'.'/'.$student->id)}}"> 
    {{$student->studentname}} </a></h5> <br/>
<h3>{{$student->student_id}}</h3> <hr/>
@endforeach 

@endsection