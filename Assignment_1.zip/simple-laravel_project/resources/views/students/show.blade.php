@extends('layouts.app')

@section('title','student')


@section('content')


<div style="background-color:#245;" class="gft">
	<a style="color:#894;font-size:22px;" class="p-4" href="{{url('/students/edit'.'/'.$student->id)}}">Edit</a>
	<a style="color:red;font-size:22px;" href="{{url('/students/destroy'.'/'.$student->id)}}">Delete</a>

	
</div>


<table class="table table-hover table-bordered text-center my-5">
	<tr>
		
		<th>student name:</th>
		
		<th>id:</th>
	</tr>
	<tr>
		
		<td>{{$student->studentname}}</td>
		
		<td>{{$student->student_id}}</td>
	</tr>

</table>

<hr/>
<!--
<img src="{{asset('/assets/images/students'.'/'.$student->image)}}">
-->
@endsection