@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
الاسهال
  <br>
 اذا كان يصاحب الاسهال نزيف او حمى، فان اعراضك قد تكون بسبب التهاب شديد في الامعاء الدقيقة او القولون
</p>
            
		<div id="demo" class="collapse">

		</div>
   
   
	
  </div>
	</div>	
    
@endsection