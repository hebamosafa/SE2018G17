@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
 الامساك
  <br>

اعراضك ربما تكون اشارة لحالة طارئة!

هذه الاعراض عندما  تظهر مع الامساك، يمكن ان تمثل مشكلة طبية تحتاج الى رعاية عاجلة، مثل: انحشار البراز او سبب اخر لانسداد الامعاء. انحشار البراز هو تراكم كبير للبراز الصلب الذي لا يتحرك.

 

اذا كانت اعراضك جديدة او شديدة، ننصحك بالخروج من هذا الدليل والاتصال بطبيبك الان من اجل التقييم العاجل
		
	
 
</p>
            
		<div id="demo" class="collapse">

		</div>
   
		
	
  </div>
	
    
@endsection