@extends('layouts.app')

@section('content')





		
<div  id ="parts" class="container text-center">
  <div id="1" class="jumbotron text-center">
	
		<p style="text-align:center; color:black;font-size:25px; font-weight:500; line-height:2rem; " class="flex-wrap py-3">
  الم الكتف
    <br>
وفقا لاجاباتك، ربما يكون الم الكتف عندك بسبب التهاب اوتار العضلات 
Tendonitis ، او الالتواء Sprain ، وربما يتحسن تلقائيا مع مرور الوقت. ولتقليل الالم، قومي باراحة كتفك، وتجنبي هذه الانشطة التي كانت قد اثارت الالم. وربما تكون جبيرة الهواء "Air Splint"، او الدعامة Brace مفيدة. وادوية الالم التي تباع دون وصفة طبية، او العلاجات الموضعية (مثل ايسي Icy Hot ، هوت او بينجاي BenGay)، او ربما يؤدي وضع الثلج الى تخفيف الالم ايضا. واذا ساءت الاعراض او لم تتحسن، قومي باستشارة طبيبك. ولفهم سبب الم كتفك بشكل افضل، ربما يكون من المفيد جمع بعض المعلومات الاضافية عنه


</p>
            
		<div id="demo" class="collapse">

		</div>
   
   
    
	
  </div>

@include('layouts.form')
		
    
@endsection